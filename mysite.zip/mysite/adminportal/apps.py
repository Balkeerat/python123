from django.apps import AppConfig


class AdminportalConfig(AppConfig):
    name = 'adminportal'
