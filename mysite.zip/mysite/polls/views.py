from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse
from django.http  import JsonResponse 
response_data = {}
response_data['Name'] = 'Balkeerat'
response_data['message'] = 'You are the json bro'
response_data['class']='123'
def index(request):
	return JsonResponse(response_data, safe=False)